#!/bin/bash

./common/listohpc
#./common/listpatterns
./common/listchanges

./common/build_tables.pl
./common/build_patterns.pl
./common/build_changelog.pl
