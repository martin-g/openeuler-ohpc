#!/bin/bash

../../../../common/build_tables.pl
../../../../common/build_patterns.pl
../../../../common/build_changelog.pl
